#ifndef __EXTI_H
#define __EXTI_H
#include "sys.h"
void IO_Exti_Init(void);

#endif
