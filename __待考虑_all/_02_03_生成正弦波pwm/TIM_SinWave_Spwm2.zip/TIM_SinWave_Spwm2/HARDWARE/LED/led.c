#include "led.h"

void LED_Init(void)
{

    GPIO_InitTypeDef GPIO_InitStucture;;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	//��ֹJ-Tag���Ź��� ��Ҫ2��  1.ʹ�ܸ���ʱ�ӹ���  2.��ֹJTAG  PB4 PA13 PA14 PA15
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE); 				//ʹ�ܸ���ʱ�ӹ���		
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 			//JTAG-DP Disabled and SW-DP Enabled

    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStucture.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_Init(GPIOC, &GPIO_InitStucture);
	
	
}

