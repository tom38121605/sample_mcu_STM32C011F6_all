#ifndef __TIMER1_H
#define __TIMER1_H
#include "sys.h"

void TIM1_PWM_Init(u16 arr, u16 psc);
void TIM1_PWM_CHN_Init(u16 arr, u16 psc);

#endif



