#include "timer2.h"
#include "led.h"
#include  "sine.h"



//APB1ʱ�ӷ�ƵΪ2  TIM2-7 ʱ����ΪAPB1 2��
// Tout= (arr+1)*(psc+1) / Tclk
void TIM2_Init(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseInitStructure.TIM_Period = arr;
    TIM_TimeBaseInitStructure.TIM_Prescaler = psc;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;			//ֻ�и߼���ʱ����Ҫ���ã�������ʱ�����Բ����á�
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM2, ENABLE);
}

u8 dc_cnt = 0;							//ռ�ձȼ���
//��ʱ��2�ж��иı� ��ʱ��1��ռ�ձ�ֵ
void TIM2_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_SetCompare1(TIM1, sinData[dc_cnt]);
        dc_cnt++;
        if(dc_cnt >= PointMax)
            dc_cnt = 0;
       
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

    }
}
