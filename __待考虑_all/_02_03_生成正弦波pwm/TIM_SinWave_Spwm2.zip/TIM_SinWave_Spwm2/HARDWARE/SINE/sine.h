#ifndef __SINE_H
#define __SINE_H
#include "sys.h"


#define  PointMax   64
extern u16 sinData[PointMax];

void get_sin_tab( u16 point );
void get_sin_tab1( u16 point, u16 maxnum );
void get_sinData(u16 point, u16 maxnum,u16 per);
void set_sin_ave(u16 per);

#endif
